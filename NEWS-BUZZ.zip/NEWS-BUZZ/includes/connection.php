<?php
$conn = mysqli_connect("localhost","root","","newsbuzz" ) or die ("error" . mysqli_error($conn));
?>